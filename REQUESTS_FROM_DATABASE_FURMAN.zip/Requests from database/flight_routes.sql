SELECT FlId, FlightDate, Fare, Departure, Arrival, Airport, Destination, AirCraft
FROM Flight_Schedule INNER JOIN AirFare ON (Flight_Schedule.NetFare=AirFare.AfID)
INNER JOIN Route ON (Route=RtID)

INSERT INTO Flight_Schedule (FlightDate, Departure, Arrival, AirCraft, NetFare) VALUES (?, ?, ?, ?, ?)

DELETE FROM Flight_Schedule WHERE FlID=?

UPDATE Flight_Schedule SET FlightDate = ?, Departure = ?, Arrival = ?, AirCraft = ?, NetFare = ? WHERE FlID = ?