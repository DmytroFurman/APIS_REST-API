SELECT Airport, Destination, Fare, RouteCode, RtId, AfID FROM AirFare INNER JOIN Route ON (AirFare.Route=Route.RtID)

SELECT * FROM Route WHERE Airport = ? AND Destination = ? AND RouteCode = ?

INSERT INTO Route (Airport, Destination, RouteCode) VALUES (?, ?, ?)

SELECT * FROM AirFare WHERE Route = ? AND Fare = ?

INSERT INTO AirFare (Route, Fare) VALUES (?, ?)

DELETE FROM AirFare WHERE Route=?

DELETE FROM Route WHERE RtID=?

UPDATE Route SET Airport =?, Destination=?, RouteCode =? WHERE RtId = ?

UPDATE AirFare SET Fare = ? WHERE AfID = ?