SELECT PsID,NAME,Age,Mobile
        FROM Transaction INNER JOIN Passenger ON (Transaction.Passenger=PsID)
        INNER JOIN Contact_Details ON (Contacts=CnID)
        WHERE Flight=?
        ORDER BY NAME