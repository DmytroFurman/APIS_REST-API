SELECT * FROM Country WHERE CountryName = ?;

INSERT INTO Country (CountryName) VALUES (?);

SELECT * FROM State WHERE StateName = ? AND Country = ?;

INSERT INTO State (StateName, Country) VALUES (?, ?);

INSERT INTO Contact_Details (Email, Mobile, State) VALUES (?, ?, ?);

INSERT INTO Passenger (Name, Address, Age, Nationality, Contacts) VALUES (?, ?, ?, ?, ?);

INSERT INTO Transaction (BookingDate, Passenger, Flight) VALUES (?, ?, ?)