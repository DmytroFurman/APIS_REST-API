SELECT PsID,NAME,Address,Nationality,Age,Mobile,Email, CountryName as CountryBirth, StateName as StateBirth FROM Passenger
        INNER JOIN Contact_Details ON (Contacts=CnID)
        INNER JOIN State ON (State=StID)
        INNER JOIN Country ON (Country=CtID)
        WHERE PsID = ?