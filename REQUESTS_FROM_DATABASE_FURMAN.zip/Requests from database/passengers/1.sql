SELECT PsID,NAME,Age,Mobile
FROM Passenger INNER JOIN Contact_Details ON (Contacts=CnID)
ORDER BY NAME