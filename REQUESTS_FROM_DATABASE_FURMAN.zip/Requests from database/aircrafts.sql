SELECT AirCraft.AcID, AirCraft.Mfg_Date, AirCraft_Type.Type, AirCraft_Type.Capacity
  FROM AirCraft INNER JOIN AirCraft_Type ON (AirCraft.Ac_Type=AirCraft_Type.ActID)

SELECT * FROM AirCraft_Type WHERE Type = ? AND Capacity = ?

INSERT INTO AirCraft_Type (Type, Capacity) VALUES (?, ?)

INSERT INTO AirCraft (Ac_Type, Mfg_Date) VALUES (?, ?)

DELETE FROM AirCraft WHERE AcID=?