const db = require('./db');
const helper = require('../helper');
const config = require('../config');

let fs = require('fs');

async function getMultiple(page = 1) {
  const offset = helper.getOffset(page, config.listPerPage);

  const dataSql = fs.readFileSync('./sql/passengers/1.sql').toString();

  const rows = await db.query(
    dataSql,
    [100, config.listPerPage]
  );
  const data = helper.emptyOrRows(rows);
  const meta = { page };

  return {
    data,
    meta,
  };
}

async function getMultipleByRoute(page = 1, routeId) {
  const offset = helper.getOffset(page, config.listPerPage);

  const dataSql = fs.readFileSync('./sql/passengers/2.sql').toString();

  const rows = await db.query(
    dataSql,
    [routeId]
  );
  const data = helper.emptyOrRows(rows);
  const meta = { page };

  return {
    data,
    meta,
  };
}

async function getSingle(page = 1, passengerId) {
  const offset = helper.getOffset(page, config.listPerPage);

  const dataSql = fs.readFileSync('./sql/passengers/3.sql').toString();

  const rows = await db.query(
    dataSql,
    [passengerId]
  );
  const data = helper.emptyOrRows(rows);
  const meta = { page };

  return {
    data,
    meta,
  };
}

async function create(passenger) {

  const dataSql = fs.readFileSync('./sql/passengers/4.sql').toString();

  const dataArr = dataSql.toString().split('\n\n');

  const typeRows = await db.query(dataArr[0],
    [passenger.CountryBirth]
  );
  const typeData = helper.emptyOrRows(typeRows);
  let type = typeData[0];

  if (!type) {
    const typeResult = await db.query(dataArr[1],
      [passenger.CountryBirth]);

    type = {}
    type.CtID = typeResult.insertId;
  }


  const typeRes = await db.query(dataArr[2],
    [passenger.StateBirth, type.CtID]
  );

  const typeData2 = helper.emptyOrRows(typeRes);
  let type2 = typeData2[0];

  if (!type2) {
    const typeResult2 = await db.query(dataArr[3],
      [passenger.StateBirth, type.CtID]);

    type2 = {}
    type2.StID = typeResult2.insertId;
  }

  const insertContactDetRes = await db.query(dataArr[4],
    [passenger.Email, passenger.Mobile, type2.StID]);

  const typeData3 = helper.emptyOrRows(insertContactDetRes);


  const insertPassengerRes = await db.query(dataArr[5],
    [passenger.NAME, passenger.Address, passenger.Age, passenger.Nationality, typeData3.insertId]);

  const typeData4 = helper.emptyOrRows(insertPassengerRes);

  let result = []

  result = await db.query(dataArr[6],
    [passenger.BookingDate, typeData4.insertId, passenger.Flight]);

  let message = 'Error in creating aircraft';

  if (result.affectedRows) {
    message = 'Aircraft created successfully';
  }

  return { message };

}

async function remove(id, route) {

  const dataSql = fs.readFileSync('./sql/passengers/5.sql').toString();

  const result = await db.query(dataSql, [id, route]);


  let message = 'Error in deleting schedule';

  if (result.affectedRows) {
    message = 'Schedule deleted successfully';
  }

  return { message };
}

// async function update(schedule, id) {
//   const result = await db.query(`UPDATE Flight_Schedule SET FlightDate = ?, Departure = ?, Arrival = ?, AirCraft = ?, NetFare = ? WHERE FlID = ?`, [schedule.FlightDate, schedule.Departure, schedule.Arrival, schedule.AcID, schedule.AfID, id]);
//
//   let message = 'Error in updating schedule';
//
//   if (result.affectedRows) {
//     message = 'Schedule updated successfully';
//   }
//
//   return { message };
// }

module.exports = {
  getMultiple,
  getMultipleByRoute,
  getSingle,
  create,
  remove,
  // update
};
