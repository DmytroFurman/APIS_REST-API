const db = require('./db');
const helper = require('../helper');
const config = require('../config');

let fs = require('fs');
const dataSql = fs.readFileSync('./sql/flight_routes.sql').toString();
const dataArr = dataSql.toString().split('\n\n');


async function getMultiple(page = 1) {
  const offset = helper.getOffset(page, config.listPerPage);
  const rows = await db.query(
    dataArr[0],
    [100, config.listPerPage]
  );
  const data = helper.emptyOrRows(rows);
  const meta = { page };

  return {
    data,
    meta,
  };
}

async function create(schedule) {

  const result = await db.query(
    dataArr[1],
    [schedule.FlightDate, schedule.Departure, schedule.Arrival, schedule.AcID, schedule.AfID]
  );

  let message = 'Error in creating schedule';

  if (result.affectedRows) {
    message = 'Schedule created successfully';
  }

  return { message };
}

async function remove(id) {
  const result = await db.query(dataArr[2], [id]);

  let message = 'Error in deleting schedule';

  if (result.affectedRows) {
    message = 'Schedule deleted successfully';
  }

  return { message };
}

async function update(schedule, id) {
  const result = await db.query(dataArr[3], [schedule.FlightDate, schedule.Departure, schedule.Arrival, schedule.AcID, schedule.AfID, id]);

  let message = 'Error in updating schedule';

  if (result.affectedRows) {
    message = 'Schedule updated successfully';
  }

  return { message };
}

module.exports = {
  getMultiple,
  create,
  remove,
  update
};
