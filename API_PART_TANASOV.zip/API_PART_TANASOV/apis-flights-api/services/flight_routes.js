const db = require('./db');
const helper = require('../helper');
const config = require('../config');

let fs = require('fs');
const dataSql = fs.readFileSync('./sql/flight_shedule.sql').toString();
const dataArr = dataSql.toString().split('\n\n');

async function getMultiple(page = 1) {
  const offset = helper.getOffset(page, config.listPerPage);
  const rows = await db.query(
    dataArr[0],
    [100, config.listPerPage]
  );
  const data = helper.emptyOrRows(rows);
  const meta = { page };

  return {
    data,
    meta,
  };
}

async function create(route) {
  const typeRows = await db.query(dataArr[1],
    [route.airport, route.destination, route.routeCode]
  );
  const typeData = helper.emptyOrRows(typeRows);
  let type = typeData[0];

  if (!type) {
    const typeResult = await db.query(dataArr[2],
      [route.airport, route.destination, route.routeCode]);

    type = {}

    type.RtID = typeResult.insertId;
  }

  const typeRes = await db.query(dataArr[3],
    [type.RtID, route.fare]
  );

  const typeData2 = helper.emptyOrRows(typeRes);
  let type2 = typeData2[0];

  let result = []

  if (!type2) {
    result = await db.query(
      dataArr[4],
      [type.RtID, route.fare]
    );
  }

  let message = 'Error in creating aircraft';

  if (result.affectedRows) {
    message = 'Aircraft created successfully';
  }

  return { message };

}

async function remove(id) {

  const result2 = await db.query(dataArr[5], [id]);

  const result = await db.query(dataArr[6], [id]);

  let message = 'Error in deleting route';

  if (result.affectedRows || result2.affectedRows) {
    message = 'route deleted successfully';
  }

  return { message };
}

async function update(route, id) {
  const result = await db.query(dataArr[7], [route.airport, route.destination, route.routeCode, id]);

  const result2 = await db.query(dataArr[8], [route.fare, route.AfID]);

  let message = 'Error in updating route';

  if (result.affectedRows && result2.affectedRows) {
    message = 'Route updated successfully';
  }

  return { message };
}

module.exports = {
  getMultiple,
  create,
  remove,
  update
};
