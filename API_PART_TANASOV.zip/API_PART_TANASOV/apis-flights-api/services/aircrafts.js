const db = require('./db');
const helper = require('../helper');
const config = require('../config');

let fs = require('fs');
const dataSql = fs.readFileSync('./sql/aircrafts.sql').toString();
const dataArr = dataSql.toString().split('\n\n');

async function getMultiple(page = 1) {
  const offset = helper.getOffset(page, config.listPerPage);
  const rows = await db.query(dataArr[0],
    [100, config.listPerPage]
  );
  const data = helper.emptyOrRows(rows);
  const meta = { page };

  return {
    data,
    meta,
  };
}

async function create(aircraft) {
  const typeRows = await db.query(dataArr[1], [
    aircraft.type,
    aircraft.capacity,
  ]);
  const typeData = helper.emptyOrRows(typeRows);
  let type = typeData[0];

  if (!type) {
    const typeResult = await db.query(dataArr[2], [
      aircraft.type,
      aircraft.capacity,
    ]);

    type = {}
    type.ActID = typeResult.insertId;
  }

  const result = await db.query(
    dataArr[3],
    [type.ActID, aircraft.year]
  );

  let message = 'Error in creating aircraft';

  if (result.affectedRows) {
    message = 'Aircraft created successfully';
  }

  return { message };
}

async function remove(id) {
  const result = await db.query(dataArr[4], [id]);

  let message = 'Error in deleting aircraft';

  if (result.affectedRows) {
    message = 'aircraft deleted successfully';
  }

  return { message };
}

module.exports = {
  getMultiple,
  create,
  remove,
};
