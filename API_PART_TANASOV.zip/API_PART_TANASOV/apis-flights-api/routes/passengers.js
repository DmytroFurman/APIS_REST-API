const express = require('express');
const router = express.Router(); 
const passengers = require('../services/passengers');

router.get('/', async function (req, res, next) {
  try {
    res.json(await passengers.getMultiple(req.query.page));
  } catch (err) {
    console.error(`Error while getting flight routes`, err.message);
    next(err);
  }
});

router.get('/route/:id', async function (req, res, next) {
  try {
    res.json(await passengers.getMultipleByRoute(req.query.page, req.params.id));
  } catch (err) {
    console.error(`Error while getting flight routes`, err.message);
    next(err);
  }
});

router.get('/:id', async function (req, res, next) {
  try {
    res.json(await passengers.getSingle(req.query.page, req.params.id));
  } catch (err) {
    console.error(`Error while getting flight routes`, err.message);
    next(err);
  }
});

router.post('/', async function (req, res, next) {
  try {
    res.json(await passengers.create(req.body));
  } catch (err) {
    console.error(`Error while creating flight route`, err.message);
    next(err);
  }
});

// router.patch('/:id', async function (req, res, next) {
//   try {
//     res.json(await passengers.update(req.body, req.params.id));
//   } catch (err) {
//     console.error(`Error while updating flight route`, err.message);
//     next(err);
//   }
// });

router.delete('/:id/:route', async function (req, res, next) {
  try {
    res.json(await passengers.remove(req.params.id, req.params.route));
  } catch (err) {
    console.error(`Error while deleting flight route`, err.message);
    next(err);
  }
});

module.exports = router;
