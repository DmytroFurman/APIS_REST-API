const express = require('express');
const router = express.Router(); 
const aircrafts = require('../services/aircrafts');

/* GET aircrafts. */
router.get('/', async function (req, res, next) {
  try {
    res.json(await aircrafts.getMultiple(req.query.page));
  } catch (err) {
    console.error(`Error while getting aircrafts`, err.message);
    next(err);
  }
});

/* POST aircraft */
router.post('/', async function (req, res, next) {
  try {
    res.json(await aircrafts.create(req.body));
  } catch (err) {
    console.error(`Error while creating aircraft`, err.message);
    next(err);
  }
});

/* DELETE aircraft */
router.delete('/:id', async function (req, res, next) {
  try {
    res.json(await aircrafts.remove(req.params.id));
  } catch (err) {
    console.error(`Error while deleting aircraft`, err.message);
    next(err);
  }
});

module.exports = router;
