const express = require('express');
const router = express.Router(); 
const flight_routes = require('../services/flight_routes');

/* GET aircrafts. */
router.get('/', async function (req, res, next) {
  try {
    res.json(await flight_routes.getMultiple(req.query.page));
  } catch (err) {
    console.error(`Error while getting flight routes`, err.message);
    next(err);
  }
});

/* POST aircraft */
router.post('/', async function (req, res, next) {
  try {
    res.json(await flight_routes.create(req.body));
  } catch (err) {
    console.error(`Error while creating flight route`, err.message);
    next(err);
  }
});

/* PATCH aircraft */
router.patch('/:id', async function (req, res, next) {
  try {
    res.json(await flight_routes.update(req.body, req.params.id));
  } catch (err) {
    console.error(`Error while updating flight route`, err.message);
    next(err);
  }
});

/* DELETE aircraft */
router.delete('/:id', async function (req, res, next) {
  try {
    res.json(await flight_routes.remove(req.params.id));
  } catch (err) {
    console.error(`Error while deleting flight route`, err.message);
    next(err);
  }
});

module.exports = router;
